

<?php $__env->startSection('content'); ?>
<section class="section container">
    <div class="section-head">
        <h1>Todas las cajas</h1>
        <p>Busca, filtra y descubre tu próxima RealityBox.</p>
    </div>

    <form method="GET" action="<?php echo e(route('products.index')); ?>" class="filters">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Buscar caja...">

        <select name="category">
            <option value="">Todas las categorías</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category); ?>" <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                    <?php echo e(ucfirst($category)); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="price">
            <option value="">Todos los precios</option>
            <option value="low" <?php echo e(request('price') == 'low' ? 'selected' : ''); ?>>Low cost</option>
            <option value="medium" <?php echo e(request('price') == 'medium' ? 'selected' : ''); ?>>Media</option>
            <option value="premium" <?php echo e(request('price') == 'premium' ? 'selected' : ''); ?>>Premium</option>
        </select>

        <select name="sort">
            <option value="">Orden por defecto</option>
            <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Precio menor</option>
            <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Precio mayor</option>
            <option value="rating" <?php echo e(request('sort') == 'rating' ? 'selected' : ''); ?>>Mejor valoradas</option>
        </select>

        <button type="submit" class="btn btn-primary">Aplicar</button>
    </form>
</section>

<?php if($popularProducts->count()): ?>
<section class="section container">
    <div class="section-head">
        <h2>Las más populares</h2>
    </div>

    <div class="grid cards-grid">
        <?php $__currentLoopData = $popularProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card compact">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <span class="tag">Top</span>
                <h3><?php echo e($product->name); ?></h3>
                <p><?php echo e(number_format($product->price, 2)); ?> €</p>
                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-dark">Ver</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<section class="section container">
    <div class="grid cards-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <span class="tag tag-secondary"><?php echo e(ucfirst($product->category)); ?></span>
                <h3><?php echo e($product->name); ?></h3>
                <p><?php echo e($product->description); ?></p>

                <div class="card-meta">
                    <span><?php echo e(number_format($product->price, 2)); ?> €</span>
                    <span>⭐ <?php echo e($product->rating); ?> (<?php echo e($product->reviews); ?>)</span>
                </div>

                <div class="card-actions">
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-dark">Ver detalle</a>
                    <a href="<?php echo e(route('products.open', $product->id)); ?>" class="btn btn-secondary">Abrir online</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No se han encontrado productos.</p>
        <?php endif; ?>
    </div>

    <div class="pagination-wrap">
        <?php echo e($products->links()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/products/index.blade.php ENDPATH**/ ?>