<?php $__env->startSection('content'); ?>
<section class="battle-builder-section">
    <div class="container">
        <div class="battle-builder-hero">
            <div>
                <span class="tag">Batallas</span>
                <h1>Crea tu batalla de cajas</h1>
                <p>Configura el modo, repite cajas con + y -, y lanza una apertura enfrentada contra bots.</p>
            </div>

            <div class="battle-builder-wallet">
                <span>Saldo demo</span>
                <strong><?php echo e(number_format(auth()->user()->demo_balance, 2)); ?> €</strong>
            </div>
        </div>
    </div>
</section>

<section class="section container">

    <?php if(session('status')): ?>
        <div class="dashboard-alert dashboard-alert-error">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('battles.start')); ?>" method="POST" class="battle-form" id="battleForm">
        <?php echo csrf_field(); ?>

        <div class="battle-panel battle-setup-panel">
            <div>
                <span class="battle-step">1</span>
                <h2>Escoge el formato</h2>
                <div class="battle-mode-grid">
                    <?php $__currentLoopData = $battleModes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modeValue => $modeLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="battle-mode">
                            <input type="radio" name="mode" value="<?php echo e($modeValue); ?>" <?php if(old('mode', $selectedMode ?? 'solo') === $modeValue): echo 'checked'; endif; ?>>
                            <span><?php echo e($modeLabel); ?></span>
                            <small>
                                <?php if($modeValue === 'solo'): ?>
                                    Tú contra la caja
                                <?php elseif($modeValue === '1v1'): ?>
                                    Tú vs bot
                                <?php elseif($modeValue === '2v2'): ?>
                                    Dos equipos de dos
                                <?php else: ?>
                                    Dos equipos de tres
                                <?php endif; ?>
                            </small>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="form-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="battle-summary-box">
                <span>Cajas seleccionadas</span>
                <strong id="battleBoxCounter">0</strong>
                <small>Máximo 10 por batalla</small>
            </div>
        </div>

        <div class="battle-panel">
            <div class="section-head split-head">
                <div>
                    <span class="battle-step">2</span>
                    <h2>Construye la tirada</h2>
                    <p>Selecciona cajas con los controles. Cada jugador abrirá exactamente la misma tirada.</p>
                </div>
            </div>

            <div class="battle-product-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $quantity = (int) old('quantities.' . $product->id, $selectedQuantities[$product->id] ?? 0);
                    ?>
                    <article class="battle-product" data-price="<?php echo e($product->price); ?>">
                        <?php if($product->image_url): ?>
                            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                        <?php else: ?>
                            <div class="battle-product-placeholder">RealityBox</div>
                        <?php endif; ?>

                        <div class="battle-product-body">
                            <span><?php echo e($product->name); ?></span>
                            <strong><?php echo e(number_format($product->price, 2)); ?> €</strong>

                            <div class="quantity-control">
                                <button type="button" class="quantity-btn" data-action="minus">-</button>
                                <input
                                    type="number"
                                    name="quantities[<?php echo e($product->id); ?>]"
                                    value="<?php echo e($quantity); ?>"
                                    min="0"
                                    max="5"
                                    data-quantity-input
                                    aria-label="Cantidad de <?php echo e($product->name); ?>"
                                >
                                <button type="button" class="quantity-btn" data-action="plus">+</button>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__errorArgs = ['quantities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="form-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['quantities.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="form-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="battle-sticky-action">
            <div>
                <span>Coste de entrada</span>
                <strong id="battleEntryCost">0.00 €</strong>
            </div>
            <button type="submit" class="btn btn-open-box" id="battleSubmitButton">Iniciar batalla</button>
        </div>
    </form>
</section>

<?php if(isset($battleTeams)): ?>
<section class="section container" id="battleResult">
    <div class="battle-arena">
        <div class="battle-arena-head">
            <div>
                <span class="tag">Resultado</span>
                <h2>Batalla en directo</h2>
                <p>
                    <?php echo e($battleBoxCount); ?> cajas por jugador · entrada <?php echo e(number_format($entryCost, 2)); ?> €.
                    La batalla se resuelve apertura por apertura.
                </p>
            </div>
            <div class="battle-live-status" id="battleLiveStatus">Preparando ruletas...</div>
        </div>

        <div class="battle-lanes">
            <?php $__currentLoopData = $battleTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamIndex => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="battle-lane" data-winner="<?php echo e($teamIndex === $winnerTeamIndex ? '1' : '0'); ?>">
                    <div class="battle-team-head">
                        <div>
                            <span class="tag tag-secondary"><?php echo e($team['name']); ?></span>
                            <h2>Equipo en combate</h2>
                        </div>
                        <strong class="battle-team-total" data-final-total="<?php echo e($team['total']); ?>">0.00 €</strong>
                    </div>

                    <div class="battle-player-list">
                        <?php $__currentLoopData = $team['players']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playerIndex => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="battle-player" data-final-total="<?php echo e($player['total']); ?>">
                                <div class="battle-player-head">
                                    <div class="battle-avatar <?php echo e($player['isUser'] ? 'user-avatar' : ''); ?>">
                                        <?php echo e($player['isUser'] ? 'T' : substr($player['name'], 0, 1)); ?>

                                    </div>
                                    <div>
                                        <h3><?php echo e($player['name']); ?></h3>
                                        <small><?php echo e($player['isUser'] ? 'Jugador' : 'Bot'); ?></small>
                                    </div>
                                    <strong class="battle-player-total">0.00 €</strong>
                                </div>

                                <div class="battle-roulette">
                                    <div class="battle-reel"></div>
                                    <div class="battle-reel-pointer"></div>
                                </div>

                                <div class="battle-reward-list">
                                    <?php $__currentLoopData = $player['openings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="battle-reward <?php echo e($opening['rarity']); ?>" data-value="<?php echo e($opening['reward']['value']); ?>">
                                            <span class="rarity-badge <?php echo e($opening['rarity']); ?>"><?php echo e($opening['rarityLabel']); ?></span>
                                            <div>
                                                <strong><?php echo e($opening['reward']['name']); ?></strong>
                                                <small>Ronda <?php echo e($opening['round']); ?> · <?php echo e($opening['product']->name); ?> · <?php echo e(number_format($opening['reward']['value'], 2)); ?> €</small>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="battle-winner-banner" id="battleWinnerBanner">
            <span>Ganador</span>
            <strong><?php echo e($battleTeams[$winnerTeamIndex]['name']); ?></strong>
            <small>
                Total: <?php echo e(number_format($battleTeams[$winnerTeamIndex]['total'], 2)); ?> €.
                <?php if($userWon): ?>
                    <?php echo e($savedOpenings); ?> recompensas añadidas a tu inventario.
                <?php else: ?>
                    No se guardan premios porque ganó el equipo bot.
                <?php endif; ?>
            </small>
        </div>

        <div class="hero-actions center battle-post-actions" id="battlePostActions">
            <a href="<?php echo e(route('battles.index')); ?>" class="btn btn-open-box">Crear otra batalla</a>
            <a href="<?php echo e(route('inventory')); ?>" class="btn btn-secondary">Ver inventario</a>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('battleForm');

    if (form) {
        const maxBoxes = 10;
        const counter = document.getElementById('battleBoxCounter');
        const entryCost = document.getElementById('battleEntryCost');
        const submitButton = document.getElementById('battleSubmitButton');
        const inputs = Array.from(form.querySelectorAll('[data-quantity-input]'));

        function totals() {
            let count = 0;
            let cost = 0;

            inputs.forEach(function (input) {
                const quantity = Math.max(0, Math.min(5, parseInt(input.value || '0', 10)));
                input.value = quantity;
                input.closest('.battle-product').classList.toggle('is-selected', quantity > 0);
                count += quantity;
                cost += quantity * parseFloat(input.closest('.battle-product').dataset.price || '0');
            });

            counter.textContent = count;
            entryCost.textContent = cost.toFixed(2) + ' €';
            submitButton.disabled = count === 0;
            form.classList.toggle('battle-limit-reached', count >= maxBoxes);
        }

        form.addEventListener('click', function (event) {
            const button = event.target.closest('.quantity-btn');
            if (!button) {
                return;
            }

            const input = button.parentElement.querySelector('[data-quantity-input]');
            const current = parseInt(input.value || '0', 10);
            const total = inputs.reduce(function (sum, item) {
                return sum + parseInt(item.value || '0', 10);
            }, 0);

            if (button.dataset.action === 'plus' && total < maxBoxes) {
                input.value = Math.min(5, current + 1);
            }

            if (button.dataset.action === 'minus') {
                input.value = Math.max(0, current - 1);
            }

            totals();
        });

        form.addEventListener('input', totals);
        totals();
    }

    const arena = document.querySelector('.battle-arena');
    if (!arena) {
        return;
    }

    const rewards = Array.from(arena.querySelectorAll('.battle-reward'));
    const winnerBanner = document.getElementById('battleWinnerBanner');
    const liveStatus = document.getElementById('battleLiveStatus');
    const postActions = document.getElementById('battlePostActions');
    const playerTotals = new Map();

    document.getElementById('battleResult').scrollIntoView({ behavior: 'smooth', block: 'start' });
    arena.classList.add('battle-running');

    rewards.forEach(function (reward, index) {
        const player = reward.closest('.battle-player');
        const team = reward.closest('.battle-lane');
        const playerTotal = player.querySelector('.battle-player-total');
        const teamTotal = team.querySelector('.battle-team-total');
        const reel = player.querySelector('.battle-reel');
        const value = parseFloat(reward.dataset.value || '0');
        const delay = 650 + (index * 520);

        playerTotals.set(player, playerTotals.get(player) || 0);
        playerTotals.set(team, playerTotals.get(team) || 0);

        setTimeout(function () {
            player.classList.add('is-spinning');
            reel.textContent = reward.querySelector('.rarity-badge').textContent;
            liveStatus.textContent = player.querySelector('h3').textContent + ' está abriendo ronda ' + reward.querySelector('small').textContent.split(' · ')[0].replace('Ronda ', '');
        }, delay - 280);

        setTimeout(function () {
            const nextPlayerTotal = playerTotals.get(player) + value;
            const nextTeamTotal = playerTotals.get(team) + value;

            playerTotals.set(player, nextPlayerTotal);
            playerTotals.set(team, nextTeamTotal);
            playerTotal.textContent = nextPlayerTotal.toFixed(2) + ' €';
            teamTotal.textContent = nextTeamTotal.toFixed(2) + ' €';
            reward.classList.add('is-visible');
            player.classList.remove('is-spinning');
            liveStatus.textContent = player.querySelector('h3').textContent + ' suma ' + value.toFixed(2) + ' €';
        }, delay);
    });

    setTimeout(function () {
        const winnerLane = arena.querySelector('[data-winner="1"]');
        if (winnerLane) {
            winnerLane.classList.add('winner-team');
            winnerLane.querySelector('.tag').classList.remove('tag-secondary');
            winnerLane.querySelector('h2').textContent = 'Ganador final';
        }

        winnerBanner.classList.add('is-visible');
        postActions.classList.add('is-visible');
        arena.classList.add('battle-finished');
        liveStatus.textContent = 'Batalla finalizada';
    }, 1000 + (rewards.length * 520));
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/battles/index.blade.php ENDPATH**/ ?>