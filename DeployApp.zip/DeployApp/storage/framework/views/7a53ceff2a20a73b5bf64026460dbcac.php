<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RealityBox</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header class="site-header">
        <div class="container nav">
            <a href="<?php echo e(route('home')); ?>" class="logo">RealityBox</a>

            <nav>
                <a href="<?php echo e(route('home')); ?>">Inicio</a>
                <a href="<?php echo e(route('products.index')); ?>">Cajas</a>
                <a href="<?php echo e(route('test')); ?>">Test</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('inventory')); ?>">Inventario</a>
                    <a href="<?php echo e(route('battles.index')); ?>">Batallas</a>
                    <span class="nav-balance"><?php echo e(number_format(auth()->user()->demo_balance, 2)); ?> €</span>
                    <?php if(auth()->user()->is_admin): ?>
                        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    <?php endif; ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="nav-logout">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Salir</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                    <a href="<?php echo e(route('register')); ?>">Registro</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\laragon\www\DeployApp\resources\views/layouts/app.blade.php ENDPATH**/ ?>