<?php $__env->startSection('content'); ?>
<section class="section container">
    <div class="dashboard-head">
        <div>
            <span class="tag">Inventario</span>
            <h1>Mis aperturas</h1>
            <p>Consulta tus premios, su rareza, valor y estado dentro de RealityBox.</p>
        </div>

        <div class="wallet-card">
            <span>Saldo demo</span>
            <strong><?php echo e(number_format(auth()->user()->demo_balance, 2)); ?> €</strong>
        </div>
    </div>

    <?php if(session('status')): ?>
        <div class="dashboard-alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="dashboard-stats">
        <div>
            <span>Total aperturas</span>
            <strong><?php echo e($stats['total']); ?></strong>
        </div>
        <div>
            <span>Guardados</span>
            <strong><?php echo e($stats['kept']); ?></strong>
        </div>
        <div>
            <span>Canjeados</span>
            <strong><?php echo e($stats['redeemed']); ?></strong>
        </div>
        <div>
            <span>Vendidos</span>
            <strong><?php echo e($stats['sold']); ?></strong>
        </div>
    </div>

    <div class="inventory-grid">
        <?php $__empty_1 = true; $__currentLoopData = $openings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="inventory-card <?php echo e($opening->rarity); ?>">
                <div class="inventory-card-head">
                    <span class="rarity-badge <?php echo e($opening->rarity); ?>"><?php echo e($opening->rarity_label); ?></span>
                    <span class="inventory-status"><?php echo e($opening->status_label); ?></span>
                </div>

                <h2><?php echo e($opening->reward_name); ?></h2>
                <p><?php echo e($opening->product_name); ?></p>

                <div class="reward-values">
                    <div>
                        <span>Valor</span>
                        <strong><?php echo e(number_format($opening->reward_value, 2)); ?> €</strong>
                    </div>
                    <div>
                        <span>Venta rápida</span>
                        <strong><?php echo e(number_format($opening->sell_price, 2)); ?> €</strong>
                    </div>
                    <div>
                        <span>Fecha</span>
                        <strong><?php echo e($opening->created_at->format('d/m/Y')); ?></strong>
                    </div>
                </div>

                <?php if($opening->status === 'pending'): ?>
                    <div class="hero-actions">
                        <form action="<?php echo e(route('openings.action', [$opening, 'keep'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary" type="submit">Guardar</button>
                        </form>
                        <form action="<?php echo e(route('openings.action', [$opening, 'redeem'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-secondary" type="submit">Canjear</button>
                        </form>
                        <form action="<?php echo e(route('openings.action', [$opening, 'sell'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-dark" type="submit">Vender</button>
                        </form>
                    </div>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">
                <h2>Aún no has abierto ninguna caja</h2>
                <p>Explora el catálogo y abre una RealityBox para llenar tu inventario.</p>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-open-box">Ver cajas</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="pagination-wrap">
        <?php echo e($openings->links()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/inventory.blade.php ENDPATH**/ ?>