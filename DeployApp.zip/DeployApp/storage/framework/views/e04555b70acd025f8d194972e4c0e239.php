<?php $__env->startSection('content'); ?>
<?php
    $heroImages = ['gamer-pro.png', 'pokemon.png', 'sneakers.png', 'tech.png', 'booster.png'];
?>

<section class="home-hero">
    <div class="hero-showcase" aria-hidden="true">
        <?php $__currentLoopData = $heroImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('images/products/' . $image)); ?>" alt="" class="hero-float hero-float-<?php echo e($index + 1); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="container home-hero-inner">
        <span class="badge">Mystery boxes premium</span>
        <h1>Abre cajas sorpresa con premios reales, rarezas y emoción online.</h1>
        <p class="hero-text">
            Elige tu temática favorita, revisa lo que puede tocarte y abre la caja con una ruleta visual.
        </p>

        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="hero-search">
            <input type="text" name="q" placeholder="Busca gaming, Pokémon, sneakers, tech...">
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>

        <div class="hero-actions">
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-open-box">Ver cajas</a>
            <a href="<?php echo e(route('test')); ?>" class="btn btn-secondary">Hacer test</a>
        </div>

        <div class="hero-trust">
            <div><strong>72%</strong><span>Común</span></div>
            <div><strong>20%</strong><span>Raro</span></div>
            <div><strong>7.2%</strong><span>Épico</span></div>
            <div><strong>0.8%</strong><span>Legendario</span></div>
        </div>
    </div>
</section>

<section class="section container home-categories">
    <div class="section-head split-head">
        <div>
            <h2>Elige tu universo</h2>
            <p>Accede directo a las categorías principales de RealityBox.</p>
        </div>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Ver catálogo</a>
    </div>

    <div class="category-showcase">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('products.index', ['category' => $category])); ?>" class="category-tile">
                <span><?php echo e(ucfirst($category)); ?></span>
                <strong>Explorar</strong>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php if($popularProducts->count()): ?>
<section class="section container">
    <div class="section-head split-head">
        <div>
            <h2>Cajas en tendencia</h2>
            <p>Las aperturas que más llaman la atención ahora mismo.</p>
        </div>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Todas las cajas</a>
    </div>

    <div class="product-carousel">
        <?php $__currentLoopData = $popularProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="carousel-card">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <div class="carousel-card-body">
                    <span class="tag">Popular</span>
                    <h3><?php echo e($product->name); ?></h3>
                    <div class="card-meta">
                        <span><?php echo e(number_format($product->price, 2)); ?> €</span>
                        <span><?php echo e(ucfirst($product->category)); ?></span>
                    </div>
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-dark">Ver caja</a>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<section class="section container">
    <div class="experience-panel">
        <div>
            <span class="tag tag-secondary">Cómo funciona</span>
            <h2>Una compra sencilla, pero con momento de apertura.</h2>
        </div>

        <div class="experience-steps">
            <div>
                <strong>1</strong>
                <h3>Elige caja</h3>
                <p>Gaming, moda, tech, cartas, franquicias o lowcost.</p>
            </div>
            <div>
                <strong>2</strong>
                <h3>Revisa premios</h3>
                <p>Cada caja muestra objetos, valor, rareza y probabilidad.</p>
            </div>
            <div>
                <strong>3</strong>
                <h3>Abre online</h3>
                <p>La ruleta revela tu recompensa final con una animación especial.</p>
            </div>
        </div>
    </div>
</section>

<?php if($featuredProducts->count()): ?>
<section class="section container">
    <div class="section-head">
        <h2>Selección destacada</h2>
        <p>Cajas preparadas para entrar directo a la experiencia.</p>
    </div>

    <div class="grid cards-grid">
        <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <span class="tag tag-secondary">Destacada</span>
                <h3><?php echo e($product->name); ?></h3>
                <p><?php echo e($product->description); ?></p>
                <div class="card-meta">
                    <span><?php echo e(number_format($product->price, 2)); ?> €</span>
                    <span><?php echo e(ucfirst($product->category)); ?></span>
                </div>
                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-dark">Ver detalle</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/welcome.blade.php ENDPATH**/ ?>