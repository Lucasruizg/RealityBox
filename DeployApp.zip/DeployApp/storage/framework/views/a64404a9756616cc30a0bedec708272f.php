<?php $__env->startSection('content'); ?>
<section class="section container">
    <div class="dashboard-head">
        <div>
            <span class="tag">Panel de gestión</span>
            <h1>Dashboard RealityBox</h1>
            <p>Gestiona cajas, categorías, precios, imágenes, populares y destacadas.</p>
        </div>

        <a href="<?php echo e(route('dashboard.products.create')); ?>" class="btn btn-open-box">Crear caja</a>
    </div>

    <?php if(session('status')): ?>
        <div class="dashboard-alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="dashboard-stats">
        <div>
            <span>Total cajas</span>
            <strong><?php echo e($totalProducts); ?></strong>
        </div>
        <div>
            <span>Destacadas</span>
            <strong><?php echo e($featuredCount); ?></strong>
        </div>
        <div>
            <span>Populares</span>
            <strong><?php echo e($popularCount); ?></strong>
        </div>
        <div>
            <span>Precio medio</span>
            <strong><?php echo e(number_format($averagePrice, 2)); ?> €</strong>
        </div>
    </div>

    <div class="dashboard-panel">
        <div class="dashboard-panel-head">
            <div>
                <h2>Cajas disponibles</h2>
                <p><?php echo e($categories->count()); ?> categorías activas en catálogo.</p>
            </div>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Ver tienda</a>
        </div>

        <div class="dashboard-table-wrap">
            <table class="dashboard-table">
                <thead>
                    <tr>
                        <th>Caja</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Rating</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="dashboard-product">
                                    <?php if($product->image_url): ?>
                                        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                                    <?php else: ?>
                                        <div class="dashboard-product-placeholder">RB</div>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?php echo e($product->name); ?></strong>
                                        <span><?php echo e($product->image ?: 'Sin imagen'); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e(ucfirst($product->category)); ?></td>
                            <td><?php echo e(number_format($product->price, 2)); ?> €</td>
                            <td><?php echo e($product->rating); ?> / 5</td>
                            <td>
                                <div class="dashboard-flags">
                                    <?php if($product->is_popular): ?>
                                        <span>Popular</span>
                                    <?php endif; ?>
                                    <?php if($product->is_featured): ?>
                                        <span>Destacada</span>
                                    <?php endif; ?>
                                    <?php if(!$product->is_popular && !$product->is_featured): ?>
                                        <span>Normal</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="dashboard-actions">
                                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-secondary">Ver</a>
                                    <a href="<?php echo e(route('dashboard.products.edit', $product->id)); ?>" class="btn btn-dark">Editar</a>
                                    <form action="<?php echo e(route('dashboard.products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('¿Eliminar esta caja?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="pagination-wrap">
            <?php echo e($products->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/dashboard.blade.php ENDPATH**/ ?>