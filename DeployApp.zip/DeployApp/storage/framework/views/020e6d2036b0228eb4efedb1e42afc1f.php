<?php $__env->startSection('content'); ?>
<?php
    $isEditing = $product->exists;
?>

<section class="section container">
    <div class="dashboard-head">
        <div>
            <span class="tag"><?php echo e($isEditing ? 'Editar caja' : 'Nueva caja'); ?></span>
            <h1><?php echo e($isEditing ? 'Actualizar RealityBox' : 'Crear RealityBox'); ?></h1>
            <p>Completa los datos del producto. La imagen debe existir en public/images/products.</p>
        </div>

        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Volver al dashboard</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="dashboard-alert dashboard-alert-error">
            Revisa los campos marcados antes de guardar.
        </div>
    <?php endif; ?>

    <form
        action="<?php echo e($isEditing ? route('dashboard.products.update', $product->id) : route('dashboard.products.store')); ?>"
        method="POST"
        class="dashboard-form"
    >
        <?php echo csrf_field(); ?>
        <?php if($isEditing): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="dashboard-form-grid">
            <label>
                Nombre
                <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Categoría
                <select name="category" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category); ?>" <?php if(old('category', $product->category) === $category): echo 'selected'; endif; ?>>
                            <?php echo e(ucfirst($category)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Precio
                <input type="number" name="price" step="0.01" min="0" value="<?php echo e(old('price', $product->price)); ?>" required>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Imagen
                <input type="text" name="image" value="<?php echo e(old('image', $product->image)); ?>" placeholder="gamer-pro.png">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Rating
                <input type="number" name="rating" step="0.1" min="0" max="5" value="<?php echo e(old('rating', $product->rating ?? 4.8)); ?>" required>
                <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Reviews
                <input type="number" name="reviews" min="0" value="<?php echo e(old('reviews', $product->reviews ?? 0)); ?>" required>
                <?php $__errorArgs = ['reviews'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        </div>

        <label>
            Descripción
            <textarea name="description" rows="5" required><?php echo e(old('description', $product->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <div class="dashboard-switches">
            <label>
                <input type="checkbox" name="is_popular" value="1" <?php if(old('is_popular', $product->is_popular)): echo 'checked'; endif; ?>>
                Marcar como popular
            </label>

            <label>
                <input type="checkbox" name="is_featured" value="1" <?php if(old('is_featured', $product->is_featured)): echo 'checked'; endif; ?>>
                Marcar como destacada
            </label>
        </div>

        <div class="hero-actions">
            <button type="submit" class="btn btn-open-box"><?php echo e($isEditing ? 'Guardar cambios' : 'Crear caja'); ?></button>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/dashboard-form.blade.php ENDPATH**/ ?>