<?php $__env->startSection('content'); ?>
<?php
    $rarityNames = [
        'comun' => 'Común',
        'raro' => 'Raro',
        'epico' => 'Épico',
        'legendario' => 'Legendario',
    ];

    $beforeItems = [
        'comun', 'raro', 'comun', 'epico', 'comun',
        'raro', 'comun', 'comun', 'raro', 'epico',
        'comun', 'raro', 'comun', 'comun', 'epico',
        'raro', 'comun', 'raro'
    ];

    $afterItems = [
        'comun', 'raro', 'comun', 'epico', 'comun',
        'raro', 'comun', 'comun', 'raro', 'epico'
    ];
?>

<section class="section container">
    <div class="open-box-wrapper">
        <span class="tag">Apertura online</span>
        <h1>Has abierto <?php echo e($product->name); ?></h1>
        <p class="open-box-subtitle">La ruleta está girando. Cuando se detenga, el marcador señalará tu rareza final.</p>

        <div class="lootbox-stage">
            <div class="lootbox-window" id="lootboxWindow">
                <div class="lootbox-track" id="lootboxTrack">
                    <?php $__currentLoopData = $beforeItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="lootbox-item <?php echo e($item); ?>">
                            <?php echo e(strtoupper($rarityNames[$item])); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="lootbox-item <?php echo e($rarityClass); ?>" id="winnerItem">
                        <?php echo e(strtoupper($rarityLabel)); ?>

                    </div>

                    <?php $__currentLoopData = $afterItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="lootbox-item <?php echo e($item); ?>">
                            <?php echo e(strtoupper($rarityNames[$item])); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="lootbox-pointer" aria-hidden="true"></div>
        </div>

        <div id="openingMessage" class="opening-message">
            Abriendo caja...
        </div>

        <div class="reward-card hidden-reward <?php echo e($rarityClass); ?>" id="rewardCard">
            <div class="rarity-badge <?php echo e($rarityClass); ?>">
                <?php echo e($rarityLabel); ?>

            </div>

            <h2><?php echo e($reward['name']); ?></h2>

            <div class="reward-values">
                <div>
                    <span>Rareza</span>
                    <strong><?php echo e($rarityLabel); ?></strong>
                </div>
                <div>
                    <span>Valor estimado</span>
                    <strong><?php echo e(number_format($reward['value'], 2)); ?> €</strong>
                </div>
                <div>
                    <span>Venta rápida</span>
                    <strong><?php echo e(number_format($sellPrice, 2)); ?> €</strong>
                </div>
            </div>
        </div>

        <div class="hero-actions center hidden-reward" id="rewardActions">
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('openings.action', [$opening, 'keep'])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary" type="submit">Quedármelo</button>
                </form>
                <form action="<?php echo e(route('openings.action', [$opening, 'redeem'])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary" type="submit">Canjearlo</button>
                </form>
                <form action="<?php echo e(route('openings.action', [$opening, 'sell'])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-dark" type="submit">Venderlo</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Inicia sesión para guardarlo</a>
            <?php endif; ?>
        </div>

        <div class="probability-box">
            <h3>Probabilidades</h3>
            <div class="probability-grid">
                <div class="prob comun">Común: <?php echo e($probabilities['comun']); ?>%</div>
                <div class="prob raro">Raro: <?php echo e($probabilities['raro']); ?>%</div>
                <div class="prob epico">Épico: <?php echo e($probabilities['epico']); ?>%</div>
                <div class="prob legendario">Legendario: <?php echo e($probabilities['legendario']); ?>%</div>
            </div>
        </div>

        <div class="hero-actions center">
            <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-secondary">Volver a la caja</a>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Seguir explorando</a>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const track = document.getElementById('lootboxTrack');
    const windowEl = document.getElementById('lootboxWindow');
    const winnerItem = document.getElementById('winnerItem');
    const rewardCard = document.getElementById('rewardCard');
    const rewardActions = document.getElementById('rewardActions');
    const openingMessage = document.getElementById('openingMessage');
    let hasFinished = false;

    function centerWinner() {
        const winnerCenter = winnerItem.offsetLeft + (winnerItem.offsetWidth / 2);
        const windowCenter = windowEl.offsetWidth / 2;
        const finalOffset = windowCenter - winnerCenter;

        track.style.setProperty('--lootbox-final-offset', finalOffset + 'px');
        if (hasFinished) {
            track.style.transform = 'translateX(' + finalOffset + 'px)';
            return;
        }

        track.classList.remove('spin-track');

        requestAnimationFrame(function () {
            track.classList.add('spin-track');
        });
    }

    centerWinner();
    window.addEventListener('resize', centerWinner);

    setTimeout(function () {
        hasFinished = true;
        openingMessage.innerText = 'Premio desbloqueado';
        winnerItem.classList.add('winner');
        rewardCard.classList.remove('hidden-reward');
        rewardActions.classList.remove('hidden-reward');
        rewardCard.classList.add('show-reward');
    }, 4300);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/products/open.blade.php ENDPATH**/ ?>