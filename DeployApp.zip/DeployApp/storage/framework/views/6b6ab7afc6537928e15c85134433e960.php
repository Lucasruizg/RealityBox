<?php $__env->startSection('content'); ?>
<section class="section container">
    <div class="result-card">
        <span class="tag">Resultado del test</span>
        <h1>Tu RealityBox recomendada</h1>
        <p class="test-intro">
            Según tus respuestas, la categoría que mejor encaja contigo es
            <strong><?php echo e(ucfirst($recommendedCategory ?? 'default')); ?></strong>.
        </p>

        <?php if($product): ?>
            <div class="card result-inner recommendation-card">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <span class="tag tag-secondary"><?php echo e(ucfirst($product->category)); ?></span>
                <h2><?php echo e($product->name); ?></h2>
                <p><?php echo e($product->description); ?></p>
                <p><strong><?php echo e(number_format($product->price, 2)); ?> €</strong></p>

                <div class="hero-actions center">
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary">Ver caja</a>
                    <a href="<?php echo e(route('products.open', $product->id)); ?>" class="btn btn-dark">Abrir online</a>
                    <a href="<?php echo e(route('test')); ?>" class="btn btn-secondary">Repetir test</a>
                </div>
            </div>
        <?php else: ?>
            <p>No hemos encontrado una caja para esa selección.</p>
            <div class="hero-actions center">
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Ver catálogo</a>
                <a href="<?php echo e(route('test')); ?>" class="btn btn-secondary">Repetir test</a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/resultado.blade.php ENDPATH**/ ?>