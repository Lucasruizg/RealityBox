

<?php $__env->startSection('content'); ?>
<section class="section container">
    <?php if(session('status')): ?>
        <div class="dashboard-alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="product-detail">
        <div class="product-box-visual">
            <?php if($product->image_url): ?>
                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-detail-image">
            <?php else: ?>
                <div class="fake-box">
                    <span>RealityBox</span>
                </div>
            <?php endif; ?>
        </div>

        <div>
            <span class="tag tag-secondary"><?php echo e(ucfirst($product->category)); ?></span>
            <h1><?php echo e($product->name); ?></h1>
            <p class="product-description"><?php echo e($product->description); ?></p>

            <div class="product-stats">
                <div><strong><?php echo e(number_format($product->price, 2)); ?> €</strong><span>Precio</span></div>
                <div><strong><?php echo e($product->rating); ?></strong><span>Rating</span></div>
                <div><strong><?php echo e($product->reviews); ?></strong><span>Reviews</span></div>
            </div>

            <div class="hero-actions">
                <a href="<?php echo e(route('products.open', $product->id)); ?>" class="btn btn-open-box">Abrir caja</a>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Volver</a>
            </div>
        </div>
    </div>
</section>

<section class="section container">
    <div class="section-head">
        <h2>Objetos que pueden tocar</h2>
        <p>Estos premios salen en esta caja según su rareza y probabilidad oficial.</p>
    </div>

    <div class="rewards-list">
        <?php $__currentLoopData = $possibleRewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $possibleReward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $rarityLabels = [
                    'comun' => 'Común',
                    'raro' => 'Raro',
                    'epico' => 'Épico',
                    'legendario' => 'Legendario',
                ];

                $rarity = $possibleReward['rarity'];
            ?>

            <div class="reward-preview <?php echo e($rarity); ?>">
                <div>
                    <span class="rarity-badge <?php echo e($rarity); ?>"><?php echo e($rarityLabels[$rarity]); ?></span>
                    <h3><?php echo e($possibleReward['name']); ?></h3>
                </div>

                <div class="reward-preview-meta">
                    <div>
                        <span>Valor</span>
                        <strong><?php echo e(number_format($possibleReward['value'], 2)); ?> €</strong>
                    </div>
                    <div>
                        <span>Probabilidad</span>
                        <strong><?php echo e($probabilities[$rarity]); ?>%</strong>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php if($relatedProducts->count()): ?>
<section class="section container">
    <div class="section-head">
        <h2>Más de esta categoría</h2>
    </div>

    <div class="grid cards-grid">
        <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card compact">
                <?php if($item->image_url): ?>
                    <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->name); ?>" class="product-image">
                <?php else: ?>
                    <div class="fake-image">RealityBox</div>
                <?php endif; ?>

                <h3><?php echo e($item->name); ?></h3>
                <p><?php echo e(number_format($item->price, 2)); ?> €</p>
                <a href="<?php echo e(route('products.show', $item->id)); ?>" class="btn btn-dark">Ver caja</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DeployApp\resources\views/products/show.blade.php ENDPATH**/ ?>